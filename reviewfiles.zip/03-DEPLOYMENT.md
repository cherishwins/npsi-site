# NPSI Site — Deployment Notes

This site is plain static HTML and CSS — no build step, no JavaScript framework, no backend. It deploys cleanly to any static-hosting platform.

## Recommended deployment

**Cloudflare Pages** — recommended for institutional sites. Free, fast global CDN, custom domain, automatic HTTPS, no analytics by default. Setup: create a Cloudflare account, connect the GitHub repository, point it at the `npsi-site` directory, deploy. Add the custom domain `npsi.ca` and Cloudflare handles DNS, certificates, and CDN.

**Netlify** or **Vercel** — equivalent options. Both offer the same workflow, both have generous free tiers, both handle custom domains and HTTPS automatically.

**GitHub Pages** — works but more limited; no custom 404 routing on the free tier without a custom domain.

## DNS / Domain

`npsi.ca` is registered (10-year registration in place). The current registrar should be confirmed; if not at Cloudflare, you can transfer the domain to Cloudflare Registrar at any point for at-cost renewal pricing — but transfers between Canadian registrars are not strictly necessary, since the site can be served from Cloudflare/Netlify/Vercel with DNS pointed from any registrar.

**Important note on `.ca` and Cloudflare:** Cloudflare Registrar does not support `.ca` domain registration directly (CIRA-accredited registrars only). If you want Cloudflare's at-cost renewal pricing, the closest approximations are using Cloudflare's DNS service while keeping the domain at a CIRA-accredited registrar (e.g., easyDNS, Hover, Namecheap, Porkbun). DNS-only management at Cloudflare is free and provides all the security benefits (DNSSEC, DDoS protection, CDN).

**Deployment steps:**

1. **Point DNS at your static host** — set CNAME or A records as the host (Cloudflare Pages / Netlify / Vercel) instructs. Do this at the registrar where `npsi.ca` is registered, OR at Cloudflare DNS if you've transferred DNS management there.
2. **Enable DNSSEC** at the registrar — `.ca` supports it; flip the toggle. Cryptographically signs DNS, prevents hijacking. Most institutional domains skip this; ours should not.
3. **Verify HTTPS** is provisioned by the static host (typically automatic, 5–15 minutes).
4. **Set up email forwarding** for `editor@npsi.ca`, `commentary@npsi.ca`, `press@npsi.ca` — registrar-level forwarding is usually free, or use a service like ImprovMX (free tier covers 25 aliases). Forward all to your existing personal inbox until volume warrants a dedicated mail provider.
5. **Configure SPF, DKIM, DMARC records** for the domain. This is the single biggest technical-credibility signal. Without them, mail from `editor@npsi.ca` lands in recipients' spam folders and forged mail can claim to be from NPSI. Most email forwarding providers walk through the DNS records to add. Set DMARC initially to `p=none` (observation mode) for two weeks, then `p=reject` for production.

## File structure

```
npsi-site/
├── index.html                    home
├── 404.html                      not-found page
├── about/index.html              about NPSI
├── engage/index.html             contribution standards
├── commentary/index.html         named commentary index
├── colophon/index.html           technical colophon
├── wp1/
│   ├── index.html                Working Paper No. 1 — full reading view
│   ├── working-paper.pdf         (drop-in: full PDF release)
│   ├── executive-brief.pdf       (drop-in: 2-page brief)
│   └── ckpif-architecture.png    (drop-in: figure)
└── assets/
    ├── css/site.css              shared stylesheet
    └── img/                      logos, favicon, OG images, figures
```

## Files to drop in before launch

The site references these files; place them at the indicated paths before launch:

1. `wp1/working-paper.pdf` — the full Working Paper No. 1 v1.0 PDF release.
2. `wp1/executive-brief.pdf` — already exists; copy from the kit.
3. `wp1/ckpif-architecture.png` — already exists; copy from the kit.

## Pre-launch checklist

- [ ] Domain registered and DNS pointed at static host
- [ ] HTTPS provisioned and verified
- [ ] Email aliases configured: `editor@npsi.ca`, `commentary@npsi.ca`
- [ ] All four PDF/image release files dropped in
- [ ] OG image renders correctly when URL is pasted into LinkedIn / Twitter / Slack preview
- [ ] All internal links verified (especially across pages: home → wp1 → engage → commentary)
- [ ] All external links verified (GitHub repo, mailto links, citation links)
- [ ] 404 page reachable
- [ ] Mobile rendering verified on iOS Safari and Android Chrome
- [ ] Form submission for mailing list either disabled or wired to a real handler (Buttondown, ConvertKit, Mailchimp — pick whichever has the cleanest no-tracking option)
- [ ] GitHub repository at `github.com/npsi-pacific/working-paper-1` exists, populated, and public
- [ ] Working Paper PDF released as a GitHub Release (not just a file in the repo)

## Mailing list integration

The current mail form is a placeholder. Recommended integration:

- **Buttondown** — minimalist, no tracking, $9/mo for the lowest paid tier
- **EmailOctopus** — generous free tier
- **ConvertKit** (now Kit) — broader feature set if needed later

Whichever you pick, the form should POST to the provider's API endpoint. Replace the `onsubmit` handler with the actual form submission.

## Analytics

Recommend **none** for v1. Institutional credibility is enhanced by the absence of tracking. If analytics become necessary later, **Plausible** (privacy-respecting, open-source, no cookies) is the recommended choice.

## Future maintenance

The site is designed to be hand-edited. To add a new working paper:

1. Create `wp[N]/index.html` modelled on `wp1/index.html`.
2. Add the working paper card to the home page.
3. Update the Commentary page with a section for the new paper.
4. Drop release files into `wp[N]/`.
5. Tag and release on GitHub.

That is the entire workflow.
