# NPSI · LinkedIn Company Page — Setup Checklist

**Recommended values for every field LinkedIn requires or offers.**
v1.0 · April 2026 · For use by the page admin (Jesse James)

---

## Page type

When you create the page, LinkedIn will ask which kind. Choose:

> **Company → Small business** (under 200 employees)

This is the right category. *Educational institution* doesn't fit (NPSI isn't accredited). *Showcase page* requires a parent page. *Company → Small business* is the institutional-credibility category that most independent think tanks and research imprints use.

---

## Identity fields

| Field | Value | Notes |
|---|---|---|
| **Page name** | `North Pacific Strategy Initiative` | Full name, no abbreviation. LinkedIn uses this verbatim everywhere the page appears. |
| **LinkedIn public URL** | `linkedin.com/company/npsi-ca` | LinkedIn auto-suggests `north-pacific-strategy-initiative` (long); manually shorten to `npsi-ca` so the LinkedIn handle exactly matches the canonical domain. If `npsi-ca` is taken, fall back to `npsi-pacific` (matches the GitHub org). The matched-identity convention — same handle on domain, LinkedIn, and GitHub — is the institutional signal. |
| **Website** | `https://npsi.ca` | Canonical domain. Registered for ten years. |
| **Industry** | `Think Tanks` | LinkedIn's actual industry category. Alternatives: `Research Services` or `Public Policy`. *Think Tanks* is the strongest signal. |
| **Company size** | `1 employee` *(or `2–10 employees` if you prefer)* | Honest. The credibility comes from the work, not the headcount. |
| **Company type** | `Privately held` | LinkedIn's options here are limited. *Nonprofit* requires registered charitable status. *Self-employed* shrinks the page. *Privately held* fits an independent imprint. |
| **Tagline** | `Working Papers on Pacific Sovereignty & Bilateral Architecture` | 120-char limit; this is 65. Matches the wordmark descriptor exactly. |
| **Logo** | Upload `npsi-square-mark-300.png` (or higher resolution) | LinkedIn requires 300×300 minimum, accepts up to 4MB. The 600px or 1200px versions render sharper on retina screens. |
| **Cover image** | Upload `npsi-cover-banner.png` | LinkedIn current spec: 1128×191. The banner shows behind the logo on the page header. |

---

## About / Description (the 2,000-character story)

LinkedIn's description field allows up to 2,000 characters. This is what shows in the "About" section. **Use the following text verbatim** — it's calibrated to fit the limit and matches the imprint's editorial voice:

> The North Pacific Strategy Initiative is an independent research imprint publishing reference-grade working papers on Pacific sovereignty, bilateral financial architecture, and the defensive options available to middle powers in a period of dollar-system stress.
>
> The Initiative is editorially independent and not affiliated with any government, institution, or commercial entity.
>
> Working papers are placed publicly under version control to enable transparent review by allied policy and academic communities. Substantive comment, technical critique, and named response are welcomed and may be incorporated into subsequent versions with full attribution.
>
> NPSI publishes occasionally — when substantive material is ready, not on a content cadence. Each working paper is editorially controlled, version-numbered, and rigorously sourced. Each is released under Creative Commons Attribution 4.0 International.
>
> Volume I, established April 2026.
>
> Editorial: editor@npsi.ca
> Named commentary: commentary@npsi.ca
> Repository: github.com/npsi-pacific
> Web: npsi.ca

---

## Specialties (up to 20 tags — pick 12–15)

LinkedIn lets you list specialty tags. These help the page surface in search. Recommended:

```
Bilateral Financial Architecture
Sovereign Debt
Pacific Policy
Canada–Korea Relations
Indo-Pacific
Indigenous Economic Reconciliation
Critical Minerals
Energy Security
Counterparty Risk
Sovereign Co-Issuance
Working Papers
Track 1.5 Diplomacy
Privacy Policy
Reference Research
```

---

## Headquarters location

| Field | Value |
|---|---|
| **Country** | Canada |
| **State / Province** | British Columbia |
| **City** | Victoria |
| **Postal code** | *(your postal code, or leave generic — e.g. V8W)* |
| **Street address** | *(optional — can leave blank for an editorial imprint)* |

LinkedIn does not require a street address for company pages. For an editorial imprint, omitting a specific street is fine and arguably more appropriate — there is no NPSI office.

---

## Founded / Established

| Field | Value |
|---|---|
| **Year founded** | `2026` |

---

## Page admin

| Field | Value |
|---|---|
| **Super admin** | Your personal LinkedIn account (Jesse James) |
| **Content admin** | (none initially — add a co-editor later if recruited) |
| **Curator** | (none) |
| **Analyst** | (none) |
| **Sponsored ad poster** | (none) |

---

## Custom button (optional but recommended)

LinkedIn lets you add a single CTA button to the top of the page. Options and the right pick:

| Button text | Use? | Reasoning |
|---|---|---|
| `Visit website` | **YES — use this** | Direct, neutral, points readers to the canonical document repository. |
| `Contact us` | No | Reads transactional. |
| `Learn more` | No | Generic. |
| `Sign up` | No | Wrong register entirely — implies marketing funnel. |
| `Register` | No | Ditto. |

Set it to: **Visit website → https://npsi.ca**

---

## Featured hashtags (up to 3)

LinkedIn lets the page follow up to three hashtags so they appear in your page feed. Recommended:

```
#PacificPolicy
#CanadaKorea
#SovereignDebt
```

---

## Locale and language

| Field | Value |
|---|---|
| **Default language** | English |
| **Additional languages** | Korean (한국어) — add when you publish Korean-language content |

LinkedIn supports per-language page content. For now, English-only is correct. When NPSI publishes a Korean version of a working paper or a Korean-audience excerpt, add Korean as an additional language and create a translated description.

---

## What to leave blank or skip

LinkedIn offers many fields that you should ignore for an editorial imprint:

- **Stock symbol / ticker** — not applicable
- **Phone number** — leave blank; email is the canonical contact
- **CEO / Founder** — LinkedIn no longer requires this; skip
- **Subsidiaries / Affiliated pages** — none
- **Showcase pages** — premature; you have one working paper
- **Career page setup** — you are not hiring
- **Lead Gen forms** — institutional discipline says no
- **LinkedIn Premium / Sales Navigator integration** — not needed

---

## After the page is live — first 48 hours

A page with no content reads as abandoned. The first three posts establish the editorial voice and prove the page is real. Recommended sequence:

**Post 1 (within 24 hours of page going live):** Announcement of Working Paper No. 1. Three sentences in your Sutter voice + link to npsi.ca/wp1. Pin this post.

**Post 2 (day 2 or 3):** A single excerpt from the executive brief — the seven-findings list, or the "what is at stake" ledger — formatted as a clean LinkedIn post with a link to the full PDF. Image: the CKPIF architecture diagram.

**Post 3 (day 5–7):** A short note about the version-controlled review model — why the working paper is on GitHub, why named commentary is welcomed, why the imprint operates this way. Establishes the editorial register.

After that, the cadence is "when there is substantive material" — same discipline as the imprint itself. No content stream, no engagement bait, no reposts. Quality only.

---

## Following / network seeding

Once the page is live, take 10 minutes to:

1. **Have your personal account follow the page.** This makes you the first follower and shows the page is real.
2. **Mark yourself as "I work here"** on your personal profile, with role: `Editor, NPSI Working Papers`. This links your personal credibility (18,660+ connections) to the page.
3. **Invite your direct connections to follow** the page. LinkedIn lets you invite up to ~250/month from your network. Be selective — pick the 100–150 connections most likely to actually engage with NPSI content (Korea-Canada policy people, defence and energy contacts, Indigenous-equity practitioners). Mass-inviting your full network looks desperate.

---

## What this page is *not* for

For the brand-discipline reasons in the NPSI brand specification:

- Not for thought-leadership content from Jesse personally — that goes on your personal profile in Sutter voice.
- Not for advocacy content on Korean reunification — that's the 주체강 brand.
- Not for energy / Libya content — that's Ibrahim Energy Partners.
- Not for civic-tech content — that's Fit For Gov.
- Not for engagement-bait, polls, or contrarian-takes content. The discipline is "be quoted, don't broadcast."

The NPSI page is the institutional anchor that makes the working papers citable. It's not a content channel.

---

*End of LinkedIn setup checklist.*
